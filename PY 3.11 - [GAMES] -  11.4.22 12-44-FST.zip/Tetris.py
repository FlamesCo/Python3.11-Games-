import turtle
import random

wn = turtle.Screen()
wn.title("Tetris")
wn.bgcolor("black")
wn.setup(width=600, height=800)
wn.tracer(0)

# Score
score = 0

# Tetriminos
tetriminos = ["L", "J", "I", "O", "S", "Z", "T"]
tetriminos_colors = ["#CC6600", "#0066CC", "#FFFF00", "#FFCC00", "#00CCCC", "#CC0000", "#6600CC"]

# Create grid
grid = [
    ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0"],
    ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0"],
    ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0"],
    ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0"],
    ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0"],
    ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0"],
    ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0"],
    ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0"],
    ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0"],
    ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0"],
    ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0"],
    ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0"],
    ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0"],
    ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0"],
    ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0"],
    ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0"],
    ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0"],
    ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0"]
]

# Tetrimino shapes
L = ["0000",
     "0010",
     "0010",
     "0110"]

J = ["0000",
     "1000",
     "1000",
     "1100"]

I = ["0000",
     "0000",
     "1111",
     "0000"]

O = ["0000",
     "0000",
     "1100",
     "1100"]

S = ["0000",
     "1100",
     "0100",
     "0000"]

Z = ["0000",
     "0100",
     "1100",
     "0000"]

T = ["0000",
     "1000",
     "1110",
     "0000"]

tetrimino_shapes = {"L": L, "J": J, "I": I, "O": O, "S": S, "Z": Z, "T": T}

# Spawn random tetrimino
def spawn_tetrimino():
    global tetrimino, tetrimino_x, tetrimino_y
    tetrimino = random.choice(tetriminos)
    tetrimino_x = 5
    tetrimino_y = 0

# Draw tetrimino
def draw_tetrimino():
    for y in range(len(tetrimino_shapes[tetrimino])):
        for x in range(len(tetrimino_shapes[tetrimino][y])):
            if tetrimino_shapes[tetrimino][y][x] == "1":
                draw_square(tetrimino_x + x, tetrimino_y + y, tetriminos_colors[tetriminos.index(tetrimino)])

# Move tetrimino left
def move_tetrimino_left():
    global tetrimino_x
    can_move = True

    for y in range(len(tetrimino_shapes[tetrimino])):
        for x in range(len(tetrimino_shapes[tetrimino][y])):
            if tetrimino_shapes[tetrimino][y][x] == "1":
                if is_out_of_bounds(tetrimino_x + x - 1, tetrimino_y + y) or grid[tetrimino_y + y][tetrimino_x + x - 1] != "0":
                    can_move = False

    if can_move:
        tetrimino_x -= 1

# Move tetrimino right
def move_tetrimino_right():
    global tetrimino_x
    can_move = True

    for y in range(len(tetrimino_shapes[tetrimino])):
        for x in range(len(tetrimino_shapes[tetrimino][y])):
            if tetrimino_shapes[tetrimino][y][x] == "1":
                if is_out_of_bounds(tetrimino_x + x + 1, tetrimino_y + y) or grid[tetrimino_y + y][tetrimino_x + x + 1] != "0":
                    can_move = False

    if can_move:
        tetrimino_x += 1

# Move tetrimino down
def move_tetrimino_down():
    global tetrimino_y
    can_move = True

    for y in range(len(tetrimino_shapes[tetrimino])):
        for x in range(len(tetrimino_shapes[tetrimino][y])):
            if tetrimino_shapes[tetrimino][y][x] == "1":
                if is_out_of_bounds(tetrimino_x + x, tetrimino_y + y + 1) or grid[tetrimino_y + y + 1][tetrimino_x + x] != "0":
                    can_move = False

    if can_move:
        tetrimino_y += 1

# Rotate tetrimino
def rotate_tetrimino():
    global tetrimino
    can_rotate = True
    next_tetrimino = tetriminos[(tetriminos.index(tetrimino) + 1) % len(tetriminos)]
    next_tetrimino_shapes = tetrimino_shapes[next_tetrimino]

    for y in range(len(next_tetrimino_shapes)):
        for x in range(len(next_tetrimino_shapes[y])):
            if next_tetrimino_shapes[y][x] == "1":
                if is_out_of_bounds(tetrimino_x + x, tetrimino_y + y) or grid[tetrimino_y + y][tetrimino_x + x] != "0":
                    can_rotate = False

    if can_rotate:
        tetrimino = next_tetrimino

# Check if position is out of bounds
def is_out_of_bounds(x, y):
    return x < 0 or x > 9 or y < 0 or y > 19

# Draw square
def draw_square(x, y, color):
    turtle.penup()
    turtle.goto(x * 20, y * 20)
    turtle.pendown()
    turtle.color(color)
    turtle.begin_fill()
    for _ in range(4):
        turtle.forward(20)
        turtle.left(90)
    turtle.end_fill()

# Clear row
def clear_row(y):
    global score

    for x in range(10):
        grid[y][x] = "0"

    score += 1

# Check if row is full
def check_row(y):
    full = True

    for x in range(10):
        if grid[y][x] == "0":
            full = False

    return full

# Clear full rows
def clear_full_rows():
    rows_cleared = 0

    for y in range(20):
        if check_row(y):
            clear_row(y)
            rows_cleared += 1

    return rows_cleared

# Check if game is over
def check_game_over():
    game_over = False

    for x in range(10):
        if grid[0][x] != "0":
            game_over = True


    return game_over
## make a mainloop
def mainloop():
    global score, game_over

    # Clear screen
    turtle.clear()
    turtle.penup()
    turtle.goto(0, 0)
    turtle.pendown()

    # Draw grid
    for y in range(20):
        for x in range(10):
            draw_square(x, y, "black")

    # Draw tetrimino
    draw_tetrimino()

    # Move tetrimino down
    move_tetrimino_down()

    # Check if tetrimino is on the ground
    on_ground = False

    for y in range(len(tetrimino_shapes[tetrimino])):
        for x in range(len(tetrimino_shapes[tetrimino][y])):
            if tetrimino_shapes[tetrimino][y][x] == "1":
                if is_out_of_bounds(tetrimino_x + x, tetrimino_y + y + 1) or grid[tetrimino_y + y + 1][tetrimino_x + x] != "0":
                    on_ground = True

    # If tetrimino is on the ground
    if on_ground:
        # Add tetrimino to grid
        for y in range(len(tetrimino_shapes[tetrimino])):
            for x in range(len(tetrimino_shapes[tetrimino][y])):
                if tetrimino_shapes[tetrimino][y][x] == "1":
                    grid[tetrimino_y + y][tetrimino_x + x] = tetrimino

        # Clear full rows
        rows_cleared = clear_full_rows()

        # Update score
        if rows_cleared == 1:
            score += 40
        elif rows_cleared == 2:
            score += 100
        elif rows_cleared == 3:
            score += 300
        elif rows_cleared == 4:
            score += 1200

        # Spawn new tetrimino
        spawn_tetrimino()

        # Check if game is over
        if check_game_over():
            game_over = True

    # Draw grid
    for y in range(20):
        for x in range(10):
            if grid[y][x] != "0":
                draw_square(x, y, tetriminos_colors[tetriminos.index(grid[y][x])])

    # Draw score
    import pygame
    pygame.init()
    pygame.mainloop()
