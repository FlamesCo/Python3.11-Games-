import turtle 

turtle.forward(100) 
turtle.left(90) 
turtle.forward(100) 
turtle.left(90) 
turtle.forward(100) 
turtle.left(90) 
turtle.forward(100)
# Path: SMB3III.py
## stop the game from quiting
turtle.done()
import pygame 
pygame.init()
pygame.mainloop()